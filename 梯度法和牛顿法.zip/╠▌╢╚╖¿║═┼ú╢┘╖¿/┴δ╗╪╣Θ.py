# 162050121赵家琛
# 时间:2022/4/10 0010 14:30
import matplotlib.pyplot as plt
import math
import numpy
import random

import numpy as np
import scipy.io

fig = plt.figure(num="岭回归")
ax = fig.add_subplot()  # rows, cols, index
order = 5  # 阶数

# 生成曲线上的各个点
data = scipy.io.loadmat('data.mat')  # 读取mat文件
x = data.get('sampx')  # 取出字典里的sampx
x = np.mat(x)  # 转成matrix类型
y = data.get('sampy')  # 取出字典里的sampy
y = np.mat(y)  # 转成matrix类型
xa = x.tolist();  # 矩阵转列表
ya = y.tolist();
ax.plot(xa, ya, color='m', linestyle='', marker='.')  # 画布

r, l = x.shape
w = np.mat(np.random.randn(order, 1))  # r*1的矩阵

X = np.mat(np.random.rand(r, order))  # 创建一个R行order列的随机小数的矩阵
for i in range(0, order):
    X[:, i] = x.A ** (i + 1)

Y = np.mat(np.random.rand(r, 1))  # 创建一个R行1列的随机小数的矩阵
for i in range(0, r):
    Y[i][0] = y[i]

eta = 0.0000001
num = 100000  # 迭代次数
for i in range(0, num):
    w = (1 - 2 * eta) * w - eta * X.T * (X * w - y)

sx = numpy.arange(-2.5, 2.5, 0.01)
sy = []
for i in range(0, len(sx)):
    yy = 0
    for j in range(1, order + 1):
        yy += (sx[i] ** j) * w[j - 1, 0]
    sy.append(yy)


ax.plot(sx, sy, color='g', linestyle='-', marker='')


plt.show()
