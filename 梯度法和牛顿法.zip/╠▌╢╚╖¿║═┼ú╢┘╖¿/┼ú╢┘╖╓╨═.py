import numpy as np
from PIL import Image


def newton_method(f, df, c, eps, max_iter):
    for i in range(max_iter):
        c2 = c - f(c) / df(c)  # 迭代公式
        if abs(f(c)) > 1e10:  # 溢出
            return None, None
        if abs(c2 - c) < eps:  # 达到收敛条件
            return c2, i  # 返回根和收敛所需的迭代次数
        c = c2


def color(ind, level):
    colors = [(180, 0, 30), (0, 180, 30), (0, 30, 180),
              (0, 190, 180), (180, 0, 175), (180, 255, 0),
              (155, 170, 180), (70, 50, 0),
              (150, 60, 0), (0, 150, 60), (0, 60, 150),
              (60, 150, 0), (60, 0, 150), (150, 0, 60),
              (130, 80, 0), (80, 130, 0), (130, 0, 80),
              (80, 0, 130), (0, 130, 80), (0, 80, 130),
              (110, 100, 0), (100, 110, 0), (0, 110, 100),
              (0, 100, 100), (110, 0, 100), (100, 0, 110),
              (255, 255, 255)]
    if ind < len(colors):
        c = colors[ind]
    else:
        c = (ind % 4 * 4, ind % 8 * 8, ind % 16 * 16)
    if max(c) < 210:
        c0 = c[0] + level
        c1 = c[1] + level
        c2 = c[2] + level
        return (c0, c1, c2)
    else:
        return c


def draw(f, df, size, name, x_min=-2.0, x_max=2., y_min=-2.0, y_max=2.0, eps=1e-6,
         max_iter=40):
    def newton_method(c):
        "c is a complex number"
        for i in range(max_iter):
            c2 = c - f(c) / df(c)
            if abs(f(c)) > 1e10:
                return None, None
            if abs(c2 - c) < eps:
                return c2, i
            c = c2

        return None, None

    roots = []  # 记录所有根
    img = Image.new("RGB", (size, size))  # 把绘画结果保存为图片
    for x in range(size):
        for y in range(size):  # 嵌套循环，遍历定义域中每个点，求收敛的根
            z_x = x * (x_max - x_min) / (size - 1) + x_min
            z_y = y * (y_max - y_min) / (size - 1) + y_min

            root, n_converge = newton_method(complex(z_x, z_y))
            if root:
                cached_root = False
                for r in roots:
                    if abs(r - root) < 1e-4:  # 判断是不是已遇到过此根
                        root = r
                        cached_root = True
                        break
                if not cached_root:
                    roots.append(root)

            if root:
                img.putpixel((x, y), color(roots.index(root), n_converge))  # 上色
    print(roots)  # 打印所有根
    img.save(name, "PNG")  # 保存图片


def f(x):
    return 4*x ** 4 + 3*x -1


def df(x):
    return 16 * x ** 3+3


# x1 sinx+x
# x2 x^5+1
# x3 x^3+2x
# x4 4x^4+3x-1
draw(f, df, 1000, "x4.png")
