# 162050121赵家琛
# 时间:2022/4/10 0010 14:30
import matplotlib.pyplot as plt
import math
import numpy
import random

import numpy as np
import scipy.io

fig = plt.figure(num="最小二乘法")
ax = fig.add_subplot()  # rows, cols, index
order = 3  # 阶数

# 生成曲线上的各个点
data = scipy.io.loadmat('data.mat')  # 读取mat文件
x = data.get('sampx')  # 取出字典里的sampx
x = np.mat(x)  # 转成matrix类型
y = data.get('sampy')  # 取出字典里的sampy
y = np.mat(y)  # 转成matrix类型
xa = x.tolist();  # 矩阵转列表
ya = y.tolist();

ax.plot(xa, ya, color='m', linestyle='', marker='.')  # 画布


# 进行曲线拟合
# 范德蒙矩阵
matA = []
for i in range(0, order + 1):
    matA1 = []
    for j in range(0, order + 1):
        tx = 0
        for k in range(0, len(xa)):
            dx = 1
            for l in range(0, j + i):
                dx = dx * xa[k][0]
            tx += dx
        matA1.append(tx)
    matA.append(matA1)
matA = numpy.array(matA)

matB = []
for i in range(0, order + 1):
    ty = 0
    for k in range(0, len(xa)):
        dy = 1
        for l in range(0, i):
            dy = dy * xa[k][0]
        ty += ya[k][0] * dy
    matB.append(ty)
matB = numpy.array(matB)

matAA = numpy.linalg.solve(matA, matB)  # 矩阵求解

# 画出拟合后的曲线
sx = numpy.arange(-2.5, 2.5, 0.01)
sy = []
for i in range(0, len(sx)):
    yy = 0.0
    for j in range(0, order + 1):
        dy = 1.0
        for k in range(0, j):
            dy *= sx[i]
        dy *= matAA[j]
        yy += dy
    sy.append(yy)
ax.plot(sx, sy, color='g', linestyle='-', marker='')
# ax.legend()  # 图例
plt.show()
